#ifndef CONSTANTS_H
#define CONSTANTS_H

//change these values at your peril!
const int constWindowWidth  = 500;
const int constWindowHeight = 500;


#endif